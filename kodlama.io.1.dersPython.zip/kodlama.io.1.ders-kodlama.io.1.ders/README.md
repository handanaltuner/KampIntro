# kodlama.io.1.ders
Python programında döngüler, şart blokları, fonksiyonlar
