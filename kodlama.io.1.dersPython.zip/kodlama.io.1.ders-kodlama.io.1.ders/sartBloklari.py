dolarDun = 7.35 #float
dolarBugun = 7.35 

#syntax
#Indentation
#true/False
if dolarBugun>dolarBugun:
  print("Azalış oku")

elif dolarDun<dolarBugun :
  print("Artış oku")
#elif dolarDun==dolarBugun:
#print ("Artış oku")

else: 
  print("Değişmedi oku")
