def kredileriListele():
  krediler = ["Hızlı Kredi","Maaşını Halkbanktan... ","Mutlu Emekli"]
  for kredi in krediler:
    print(kredi)

kredileriListele()
