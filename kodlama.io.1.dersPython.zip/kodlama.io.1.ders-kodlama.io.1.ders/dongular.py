kredi1 = "Hızlı Kredi"
kredi2 = "Maaşını Halkbanktan... "
kredi3 = "Mutlu Emekli"

print(kredi1)
print(kredi2)
print(kredi3)

krediler =["Hızlı Kredi","Maaşını Halkbanktan... ","Mutlu Emekli"]

for kredi in krediler:
  print(kredi)