

baslik = "ilginizi çekebilir!"
vade = 48
faizOrani = 1.69

print('Baslık : ' +  baslik)
print(vade + vade)
print(faizOrani)

print(type(baslik))
print(type(vade))
print(type(faizOrani))



